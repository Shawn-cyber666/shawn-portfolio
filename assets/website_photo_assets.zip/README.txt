Website photo assets prepared in 16:9 for the Lens film reel.
Files:
- photo-01.jpg to photo-11.jpg
- film-track-snippet.html (replace your existing Lens film-track block with this snippet)
- processed_contact_sheet.jpg (quick preview)
Recommended upload path in repo: assets/
